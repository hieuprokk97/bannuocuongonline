from django.apps import AppConfig


class ThanhToanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.thanh_toan'
