# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from apps.nguoi_dung.models import NguoiDung

class KhachHang(models.Model):
    ma_khach_hang = models.IntegerField(primary_key=True)
    ten_khach_hang = models.CharField(max_length=40)
    khach_hang_thuong_xuyen = models.IntegerField()
    ma_nguoi_dung = models.ForeignKey(NguoiDung, on_delete=models.PROTECT, db_column='ma_nguoi_dung')

    def __str__(self):
        return f"{self.ma_khach_hang}, {self.ten_khach_hang}, {self.khach_hang_thuong_xuyen}"
    class Meta:
        managed = True
        db_table = 'khach_hang'
