from django.apps import AppConfig


class KhachHangConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.khach_hang'
