from django.apps import AppConfig


class KhuyenMaiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.khuyen_mai'
