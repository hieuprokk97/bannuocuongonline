from django.shortcuts import render

from apps.san_pham.models import SanPham as SanPham_Model
from apps.loai_san_pham.models import LoaiSanPham as LoaiSanPham_model
# Create your views here.
