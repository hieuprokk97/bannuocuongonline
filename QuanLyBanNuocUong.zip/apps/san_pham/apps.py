from django.apps import AppConfig


class SanPhamConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.san_pham'
    
