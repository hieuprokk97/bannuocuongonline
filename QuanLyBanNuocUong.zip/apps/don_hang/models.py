# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from apps.khach_hang.models import KhachHang
from apps.khuyen_mai.models import KhuyenMai
from apps.shipper.models import Shipper
from apps.san_pham.models import SanPham
class DonHang(models.Model):
    ma_don_hang = models.IntegerField(primary_key=True)
    ngay_dat = models.DateTimeField()
    ngay_giao = models.DateTimeField()
    so_nha = models.CharField(max_length=30)
    duong = models.CharField(max_length=30)
    phuong = models.CharField(max_length=30)
    quan = models.CharField(max_length=30)
    thanh_pho = models.CharField(max_length=30)
    tong_tien_hang = models.DecimalField(max_digits=10, decimal_places=2)
    ap_dung_khuyen_mai = models.IntegerField()
    gia_tri_khuyen_mai = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    tong_so_tien = models.DecimalField(max_digits=10, decimal_places=2)
    ma_khuyen_mai = models.ForeignKey(KhuyenMai, on_delete=models.PROTECT, db_column='ma_khuyen_mai')
    ma_khach_hang = models.ForeignKey(KhachHang, on_delete=models.PROTECT, db_column='ma_khach_hang')
    ma_shipper = models.ForeignKey(Shipper, on_delete=models.PROTECT, db_column='ma_shipper')
    ma_san_pham = models.ForeignKey(SanPham, on_delete=models.PROTECT, db_column='ma_san_pham')

    class Meta:
        managed = True
        db_table = 'don_hang'
