from django.apps import AppConfig


class ChiTietDonHangConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.chi_tiet_don_hang'
