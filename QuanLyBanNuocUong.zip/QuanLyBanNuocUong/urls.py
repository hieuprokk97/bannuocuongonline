import imp
from django.conf import settings
from django.contrib import admin
from django.urls import path
from apps.home import views as home
from apps.san_pham import views as sanpham
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home.get_home, name='home'),
    path("signin", home.signin),
    path("signup", home.signup, name="signup"),
    path("signout", home.signout),
    path("cart", home.cart, name="cart"),
    path("shop", home.shop, name='shop'),
    path("update_item/", home.updateItem, name="update_item"),
    path("shop/maloai/<str:id>", home.maloai, name='San Pham Thuoc Danh Muc'),
    path("shop/detail/<str:id>", home.detail, name='Chi tiet san pham')
]
urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
admin.site.site_header = "SodaPopStop"